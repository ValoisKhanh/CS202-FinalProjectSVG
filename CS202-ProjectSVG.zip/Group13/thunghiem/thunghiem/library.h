#include <objidl.h>
#include <vector>
#include <string>
#include<fstream>
#include<sstream>
#include<iostream>
#include<Gdiplus.h>
#include"rapidxml.hpp"
#include"rapidxml_iterators.hpp"
#include"rapidxml_print.hpp"
#include"rapidxml_utils.hpp"
using namespace std;
using namespace Gdiplus;
using namespace rapidxml;
#pragma comment (lib,"Gdiplus.lib")